# 辭典資料來源與授權

本程式的英語詞彙語義架構以 **Open English WordNet** 為基礎。

- 專案網站：https://en-word.net/
- 原始碼與資料：https://github.com/globalwordnet/english-wordnet
- 授權：Creative Commons Attribution 4.0 International（CC BY 4.0）
- 授權全文：https://creativecommons.org/licenses/by/4.0/

Open English WordNet 由 Open English WordNet Community 維護，源自 Princeton WordNet。中文輔助解釋、字首字根拆解、記憶提示與教學編排由本專案另外整理，不代表 Open English WordNet 官方翻譯。

## ECDICT

`toeic_vocabulary.json` 的英中詞義與詞形資料取自 **ECDICT**，固定來源版本為 `bc6b25957f1dbb745768bb734b20a613edf7fdbe`。

- 專案：https://github.com/TheOpenDictionary/ecdict
- 授權：MIT License
- Copyright (c) 2017 Linwei

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## 大考中心詞彙分級參考

本工具參考大考中心現行高中英文參考詞彙表的六級架構安排學習難度。官方現行表約為 6,000 詞；本工具的 7,000 詞是自行延伸的備考範圍，不是官方詞表的重製或官方認證內容。

- 說明：https://www.ceec.edu.tw/xcepaper/cont?qperoid=0K220613903738311866&sid=0K227548677326460907&xsmsid=0J066588036013658199
- 官方參考詞彙表：https://www.ceec.edu.tw/files/file_pool/1/0K213612821879129835/%E9%AB%98%E4%B8%AD%E8%8B%B1%E6%96%87%E5%8F%83%E8%80%83%E8%A9%9E%E5%BD%99%E8%A1%A8%28111%E5%AD%B8%E5%B9%B4%E5%BA%A6%E8%B5%B7%E9%81%A9%E7%94%A8%29.pdf
