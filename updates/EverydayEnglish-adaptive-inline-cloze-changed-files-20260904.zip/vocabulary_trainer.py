#!/usr/bin/env python3
"""互動式英文單詞練習器（僅使用 Python 標準函式庫）。"""

from __future__ import annotations

import json
import os
import random
import re
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta
from pathlib import Path


def progress_file() -> Path:
    """使用可寫入的使用者資料夾，避免 Windows 安裝目錄權限問題。"""
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home()))
        return base / "EverydayEnglish" / "vocabulary_progress.json"
    return Path.home() / ".everyday_english" / "vocabulary_progress.json"


DATA_FILE = progress_file()


@dataclass(frozen=True)
class Word:
    word: str
    meaning: str
    level: int
    example: str
    pattern: str
    memory: str


WORDS = [
    Word("apple", "蘋果", 1, "I eat an apple every morning.", "常用名詞；不必硬拆字根", "把 a + pp + le 分成三小段來拼。"),
    Word("water", "水；澆水", 1, "Please drink more water.", "可作名詞或動詞；不必硬拆字根", "想像 water 在杯子裡晃動。"),
    Word("family", "家庭；家人", 1, "My family eats dinner together.", "常用名詞；整個單詞一起記", "family 裡有 I：I love my family。"),
    Word("friend", "朋友", 1, "She is my best friend.", "常用名詞；不必硬拆字根", "記住固定順序：fri-end，朋友陪你到 end。"),
    Word("happy", "快樂的", 1, "The children look happy.", "-y：常見形容詞字尾", "happy 以雙 p 拼寫，結尾是 y。"),
    Word("school", "學校", 1, "The school is near my home.", "常用名詞；不必硬拆字根", "sch 開頭，後面是雙 o。"),
    Word("morning", "早晨；上午", 1, "I walk to work every morning.", "-ing：此處構成表示時段的名詞", "morn + ing，早晨這段時間。"),
    Word("listen", "聽；傾聽", 1, "Listen carefully to the question.", "常用動詞；不必硬拆字根", "t 不發音，但拼字時不能漏。"),
    Word("answer", "回答；答案", 1, "Can you answer this question?", "可作名詞或動詞；不必硬拆字根", "w 不發音：拼作 ans-wer。"),
    Word("enough", "足夠的；足夠地", 1, "We have enough food for everyone.", "可作形容詞或副詞；不必硬拆字根", "e-nough；gh 不發音，讀音近「依納夫」。"),
    Word("go", "去；前往", 1, "I go to work by bus.", "常用不規則動詞；整體記憶變化", "go 的過去式是 went，過去分詞是 gone。"),
    Word("eat", "吃", 1, "We eat dinner at seven.", "常用不規則動詞；整體記憶變化", "eat－ate－eaten，以三段節奏記憶。"),
    Word("see", "看見；理解", 1, "I see my friends every weekend.", "常用不規則動詞；整體記憶變化", "see－saw－seen，注意三種形式不同。"),
    Word("important", "重要的", 2, "Sleep is important for your health.", "-ant：常見形容詞字尾", "注意中間是 port，結尾是 -ant。"),
    Word("different", "不同的", 2, "This answer is different from mine.", "-ent：常見形容詞字尾", "different 中間有雙 f，結尾是 -ent。"),
    Word("remember", "記得；想起", 2, "Remember to lock the door.", "re- 常表示「再次」；此字以整體意思記憶", "把事情重新帶回腦中，就是 remember。"),
    Word("decide", "決定", 2, "We need to decide before noon.", "常用動詞；不必硬拆字根", "先記 de-ci-de 的拼寫節奏。"),
    Word("improve", "改善；進步", 2, "Reading daily will improve your English.", "im- 在此不是否定；不要一律解作「不」", "im + prove 合起來記成 improve。"),
    Word("prepare", "準備", 2, "I need to prepare for the meeting.", "pre-：常表示「在前、預先」", "事前 prepare，就是預先準備。"),
    Word("careful", "小心的；仔細的", 2, "Be careful when crossing the street.", "-ful：常見形容詞字尾，表示「充滿…的」", "care + ful＝充滿留意與關心。"),
    Word("possible", "可能的；可行的", 2, "Is it possible to finish today?", "-ible：常見形容詞字尾，表示「可以…的」", "possible 中間是雙 s，結尾是 -ible。"),
    Word("receive", "收到；接收", 2, "Did you receive my message?", "常用動詞；不必硬拆字根", "i before e，但 c 後面例外：receive。"),
    Word("because", "因為", 2, "I stayed home because it was raining.", "連接詞；不必硬拆字根", "拆成 be + cause 幫助記拼寫即可。"),
    Word("make", "製作；使成為", 2, "We make breakfast together.", "常用不規則動詞；整體記憶變化", "make－made－made，過去式與過去分詞相同。"),
    Word("take", "拿取；花費；搭乘", 2, "I take the train to work.", "常用不規則動詞；整體記憶變化", "take－took－taken，三種形式分開記。"),
    Word("communicate", "溝通；傳達", 3, "Good teams communicate clearly.", "-ate：常見動詞字尾", "communicate 中間有雙 m。"),
    Word("experience", "經驗；經歷", 3, "Travel gives us valuable experience.", "-ence：常見名詞字尾；此字也可作動詞", "結尾固定拼成 -ence。"),
    Word("environment", "環境", 3, "We should protect the environment.", "-ment：常見名詞字尾", "environment＝environ + ment。"),
    Word("opportunity", "機會", 3, "This job is a great opportunity.", "-ity：常見名詞字尾", "注意中間是雙 p，結尾是 -ity。"),
    Word("responsible", "負責任的", 3, "You are responsible for this project.", "-ible：常見形容詞字尾", "respons + ible，注意不是 -able。"),
    Word("available", "可取得的；有空的", 3, "Is this seat available?", "-able：常見形容詞字尾，表示「可以…的」", "avail + able，兩段接起來。"),
    Word("recommend", "推薦；建議", 3, "I recommend the vegetable soup.", "常用動詞；re- 在此不必單獨硬譯", "recommend 中間是雙 m。"),
    Word("necessary", "必要的", 3, "A passport is necessary for the trip.", "-ary：常見形容詞字尾", "一個 c、雙 s：necessary。"),
    Word("successful", "成功的", 3, "Practice is the key to being successful.", "-ful：常見形容詞字尾", "success + ful；success 的雙 c、雙 s 要保留。"),
    Word("convenient", "方便的", 3, "Online banking is convenient.", "-ent：常見形容詞字尾", "conveni + ent，注意中間的 i。"),
    Word("significant", "重要的；顯著的", 4, "There was a significant improvement.", "-ant：常見形容詞字尾", "signific + ant，結尾不是 -ent。"),
    Word("perspective", "觀點；視角", 4, "Try to see it from her perspective.", "常用名詞；不必為了拆字而硬解釋", "想到從某個角度觀看，就連結 perspective。"),
    Word("efficient", "有效率的", 4, "This is a more efficient way to work.", "-ent：常見形容詞字尾", "efficient 中間有雙 f，結尾是 -cient。"),
    Word("consequence", "結果；後果", 4, "Every choice has a consequence.", "-ence：常見名詞字尾", "consequ + ence，結尾固定是 -ence。"),
    Word("essential", "不可或缺的；本質的", 4, "Trust is essential in a friendship.", "-ial：常見形容詞字尾", "essential 中間是雙 s。"),
    Word("maintain", "維持；保養", 4, "Exercise helps maintain good health.", "常用動詞；不必硬拆字根", "main + tain，兩段都有 ain。"),
    Word("independent", "獨立的；自主的", 4, "She became financially independent.", "in-：此處表否定；-ent：形容詞字尾", "in + dependent＝不依賴的。"),
    Word("appropriate", "合適的；恰當的", 4, "Wear appropriate clothes for the event.", "-ate：此處是形容詞字尾", "appropriate 中間有雙 p。"),
    Word("evaluate", "評估；評價", 4, "We need to evaluate the results.", "-ate：常見動詞字尾", "value 變成 evaluate，保留 valu 的拼寫。"),
    Word("acknowledge", "承認；確認收到", 4, "He acknowledged his mistake.", "常用動詞；不必硬拆字根", "先看成 ac + knowledge 來記拼寫。"),
]

# 保留人工教材基礎詞清單，供離線字庫建置與範圍標記使用。
FOUNDATION_WORDS = tuple(WORDS)


# 學習卡上的實用用法。刻意聚焦詞性、常見搭配與句型，不機械式拆解字根。
WORD_USAGE: dict[str, tuple[str, str, str]] = {
    "apple": ("名詞（可數）", "apple pie；apple juice；an apple a day", "單數用 an apple；複數為 apples。"),
    "water": ("名詞（不可數）／動詞", "drink water；a glass of water；water the plants", "表示液體時通常不可數；作動詞可直接接受詞。"),
    "family": ("名詞（可數／集合名詞）", "family member；family life；spend time with family", "美式英語常把 family 視為單數：My family is ...。"),
    "friend": ("名詞（可數）", "close friend；make friends with；a friend of mine", "make friends with + 人；a friend of + 所有格代名詞。"),
    "happy": ("形容詞", "be happy with；be happy about；make someone happy", "連綴動詞 be／feel／look 後接形容詞 happy。"),
    "school": ("名詞（可數）", "go to school；after school；school day", "go to school 表示上學時通常不加冠詞。"),
    "morning": ("名詞", "in the morning；every morning；tomorrow morning", "in the morning；但 every／tomorrow morning 前不加介系詞。"),
    "listen": ("動詞", "listen to music；listen carefully；listen for a sound", "接受詞時要用 listen to + 名詞；祈使句可省略主詞。"),
    "answer": ("名詞／動詞", "answer a question；the answer to；answer the phone", "動詞 answer 直接接受詞；名詞用 the answer to + 問題。"),
    "enough": ("限定詞／代名詞／副詞", "enough time；good enough；more than enough", "enough + 名詞；形容詞／副詞 + enough。"),
    "go": ("動詞（不規則）", "go to work；go home；go abroad", "go－went－gone；go home 中間不加 to。"),
    "eat": ("動詞（不規則）", "eat breakfast；eat out；something to eat", "eat－ate－eaten；三餐名稱前通常不加冠詞。"),
    "see": ("動詞（不規則）", "see a doctor；see someone off；I see", "see－saw－seen；see someone do／doing 表示看見某人做事。"),
    "important": ("形容詞", "important to someone；important for something；most important", "It is important to + 原形動詞；important for + 名詞。"),
    "different": ("形容詞", "different from；completely different；make a difference", "be different from + 名詞／代名詞。"),
    "remember": ("動詞", "remember to do；remember doing；remember clearly", "remember to do 是記得去做；remember doing 是記得做過。"),
    "decide": ("動詞", "decide to do；decide on；make a decision", "decide to + 原形動詞；decide that + 完整子句。"),
    "improve": ("動詞（及物／不及物）", "improve your English；improve greatly；room for improvement", "可直接接受詞，也可不接受詞：My English improved.。"),
    "prepare": ("動詞", "prepare for；prepare a meal；be prepared to", "prepare for + 名詞；prepare to + 原形動詞。"),
    "careful": ("形容詞", "be careful with；be careful about；careful planning", "Be careful not to + 原形動詞，表示小心不要做某事。"),
    "possible": ("形容詞", "if possible；as soon as possible；make it possible", "It is possible to + 原形動詞；不以人作 possible 的主詞補語。"),
    "receive": ("動詞", "receive a message；receive from；receive treatment", "及物動詞，直接接事物：receive something from someone。"),
    "because": ("連接詞", "because of；just because；mainly because", "because + 子句；because of + 名詞／動名詞。"),
    "make": ("動詞（不規則）", "make a decision；make sure；make someone happy", "make－made－made；make + 受詞 + 原形動詞／形容詞。"),
    "take": ("動詞（不規則）", "take a break；take care of；take the train", "take－took－taken；It takes + 時間 + to do。"),
    "communicate": ("動詞", "communicate with；communicate clearly；communicate a message", "communicate with + 人；communicate about + 主題。"),
    "experience": ("名詞／動詞", "gain experience；work experience；experience difficulty", "泛指經驗時不可數；指一次經歷時可數。"),
    "environment": ("名詞", "protect the environment；work environment；safe environment", "指自然環境常用 the environment；特定環境可用 a/an。"),
    "opportunity": ("名詞（可數）", "opportunity to do；job opportunity；take the opportunity", "an opportunity to + 原形動詞；opportunity for + 名詞。"),
    "responsible": ("形容詞", "responsible for；person responsible；socially responsible", "be responsible for + 名詞／動名詞。"),
    "available": ("形容詞", "available to；available for；readily available", "be available to + 人；be available for + 用途／時間。"),
    "recommend": ("動詞", "highly recommend；recommend doing；recommend that", "recommend + 動名詞，或 recommend that + 主詞 + 原形動詞。"),
    "necessary": ("形容詞", "if necessary；necessary for；necessary steps", "It is necessary to + 原形動詞；necessary for + 名詞。"),
    "successful": ("形容詞", "successful in；highly successful；successful career", "be successful in + 名詞／動名詞。"),
    "convenient": ("形容詞", "convenient for；convenient time；quick and convenient", "It is convenient for someone to do；通常不說人很 convenient。"),
    "significant": ("形容詞", "significant difference；significant increase；statistically significant", "可用 significant to／for 表示對某人或某事重要。"),
    "perspective": ("名詞（可數）", "from my perspective；different perspective；put into perspective", "from + 所有格 + perspective，表示從某人的觀點。"),
    "efficient": ("形容詞", "energy-efficient；efficient way；highly efficient", "比較級通常用 more efficient；be efficient at/in + 名詞。"),
    "consequence": ("名詞（可數）", "as a consequence；consequence of；face the consequences", "as a consequence 表結果；the consequence of + 原因。"),
    "essential": ("形容詞／名詞", "essential for；essential to；absolutely essential", "It is essential to + 原形動詞；essential for/to + 名詞。"),
    "maintain": ("動詞", "maintain standards；maintain contact；maintain that", "及物動詞；maintain that + 子句可表示堅稱。"),
    "independent": ("形容詞", "independent of；financially independent；independent study", "be independent of/from + 名詞；become/remain independent。"),
    "appropriate": ("形容詞", "appropriate for；appropriate response；where appropriate", "It is appropriate to + 原形動詞；appropriate for + 情境／人物。"),
    "evaluate": ("動詞", "evaluate results；evaluate performance；carefully evaluate", "及物動詞，後面直接接要評估的事物。"),
    "acknowledge": ("動詞", "acknowledge a mistake；acknowledge receipt；widely acknowledged", "acknowledge + 名詞／動名詞，或 acknowledge that + 子句。"),
}

PHRASE_NOTES: dict[str, str] = {
    "apple": "apple pie（蘋果派）；apple juice（蘋果汁）；an apple a day（一天一顆蘋果）",
    "water": "drink water（喝水）；a glass of water（一杯水）；water the plants（澆植物）",
    "family": "family member（家庭成員）；family life（家庭生活）；spend time with family（陪伴家人）",
    "friend": "close friend（親近的朋友）；make friends with（和……交朋友）；a friend of mine（我的一位朋友）",
    "happy": "be happy with（對……滿意）；be happy about（因……高興）；make someone happy（使某人開心）",
    "school": "go to school（去上學）；after school（放學後）；school day（上學日）",
    "morning": "in the morning（在早上）；every morning（每天早上）；tomorrow morning（明天早上）",
    "listen": "listen to music（聽音樂）；listen carefully（仔細聽）；listen for a sound（留心聽某個聲音）",
    "answer": "answer a question（回答問題）；the answer to（……的答案）；answer the phone（接電話）",
    "enough": "enough time（足夠的時間）；good enough（夠好）；more than enough（綽綽有餘）",
    "go": "go to work（去上班）；go home（回家）；go abroad（出國）",
    "eat": "eat breakfast（吃早餐）；eat out（外出用餐）；something to eat（一些吃的東西）",
    "see": "see a doctor（去看醫生）；see someone off（替某人送行）；I see（我明白了）",
    "important": "important to someone（對某人重要）；important for something（對某事重要）；most important（最重要的）",
    "different": "different from（與……不同）；completely different（完全不同）；make a difference（產生影響）",
    "remember": "remember to do（記得要做）；remember doing（記得做過）；remember clearly（清楚記得）",
    "decide": "decide to do（決定做）；decide on（選定）；make a decision（作決定）",
    "improve": "improve your English（提升英語）；improve greatly（大幅改善）；room for improvement（改善空間）",
    "prepare": "prepare for（為……準備）；prepare a meal（準備餐點）；be prepared to（準備好要……）",
    "careful": "be careful with（小心處理）；be careful about（留意……）；careful planning（周詳規劃）",
    "possible": "if possible（如果可以）；as soon as possible（儘快）；make it possible（使之成為可能）",
    "receive": "receive a message（收到訊息）；receive from（從……收到）；receive treatment（接受治療）",
    "because": "because of（因為……）；just because（只因為）；mainly because（主要因為）",
    "make": "make a decision（作決定）；make sure（確認）；make someone happy（使某人開心）",
    "take": "take a break（休息一下）；take care of（照顧）；take the train（搭火車）",
    "communicate": "communicate with（與……溝通）；communicate clearly（清楚表達）；communicate a message（傳達訊息）",
    "experience": "gain experience（累積經驗）；work experience（工作經驗）；experience difficulty（遭遇困難）",
    "environment": "protect the environment（保護環境）；work environment（工作環境）；safe environment（安全的環境）",
    "opportunity": "opportunity to do（做……的機會）；job opportunity（工作機會）；take the opportunity（把握機會）",
    "responsible": "responsible for（負責……）；person responsible（負責人）；socially responsible（對社會負責）",
    "available": "available to（可供……使用）；available for（可用於……）；readily available（容易取得）",
    "recommend": "highly recommend（強力推薦）；recommend doing（建議做……）；recommend that（建議……）",
    "necessary": "if necessary（如有必要）；necessary for（對……必要）；necessary steps（必要步驟）",
    "successful": "successful in（在……方面成功）；highly successful（非常成功）；successful career（成功的職涯）",
    "convenient": "convenient for（對……方便）；convenient time（方便的時間）；quick and convenient（快速又方便）",
    "significant": "significant difference（顯著差異）；significant increase（顯著增加）；statistically significant（具統計顯著性）",
    "perspective": "from my perspective（從我的觀點）；different perspective（不同觀點）；put into perspective（客觀看待）",
    "efficient": "energy-efficient（節能的）；efficient way（有效率的方法）；highly efficient（非常有效率）",
    "consequence": "as a consequence（因此）；consequence of（……的後果）；face the consequences（承擔後果）",
    "essential": "essential for（對……不可或缺）；essential to（對……至關重要）；absolutely essential（絕對必要）",
    "maintain": "maintain standards（維持標準）；maintain contact（保持聯絡）；maintain that（堅稱……）",
    "independent": "independent of（不依賴……）；financially independent（經濟獨立）；independent study（自主學習）",
    "appropriate": "appropriate for（適合……）；appropriate response（恰當的回應）；where appropriate（在適當情況下）",
    "evaluate": "evaluate results（評估結果）；evaluate performance（評估表現）；carefully evaluate（仔細評估）",
    "acknowledge": "acknowledge a mistake（承認錯誤）；acknowledge receipt（確認收到）；widely acknowledged（廣受認可）",
}


# 依 ETS 公開的 TOEIC 日常職場情境整理；並非 ETS 官方公布的必考清單。
# 欄位：單詞、中譯、級別、例句、詞性、常用搭配（含中譯）、重點文法、情境分類。
TOEIC_CORE_DATA = [
    ("agenda", "議程", 1, "The meeting agenda is attached to the email.", "名詞（可數）", "meeting agenda（會議議程）；set the agenda（制定議程）；on the agenda（列入議程）", "agenda 前可用 an；on the agenda 表示列在議程中。", "辦公與會議"),
    ("appointment", "約會；預約", 1, "I have an appointment with the manager at ten.", "名詞（可數）", "make an appointment（預約）；keep an appointment（如期赴約）；appointment with（與……的約會）", "have an appointment with + 人；at + 時間。", "辦公與會議"),
    ("confirm", "確認", 1, "Please confirm your attendance by Friday.", "動詞", "confirm attendance（確認出席）；confirm a reservation（確認預訂）；confirm that（確認……）", "confirm + 名詞，或 confirm that + 完整子句。", "辦公與會議"),
    ("deadline", "截止期限", 1, "The deadline for the report is Monday.", "名詞（可數）", "meet a deadline（如期完成）；miss a deadline（錯過期限）；deadline for（……的期限）", "the deadline for + 名詞；by the deadline 表示在期限前。", "辦公與會議"),
    ("document", "文件；記錄", 1, "Please sign the document before the meeting.", "名詞／動詞", "sign a document（簽署文件）；supporting documents（證明文件）；document the process（記錄流程）", "作名詞時可數；作動詞時直接接受詞。", "辦公與會議"),
    ("schedule", "行程；安排", 1, "The training session is scheduled for Tuesday.", "名詞／動詞", "on schedule（按進度）；ahead of schedule（提前）；schedule a meeting（安排會議）", "be scheduled for + 日期／時間；schedule + 受詞。", "辦公與會議"),
    ("applicant", "申請人", 2, "Each applicant must submit a résumé.", "名詞（可數）", "job applicant（求職者）；qualified applicant（合格申請人）；successful applicant（錄取者）", "applicant for + 職位／計畫；each 後接單數名詞。", "人事與招募"),
    ("candidate", "候選人；應徵者", 2, "Three candidates were invited to an interview.", "名詞（可數）", "job candidate（求職候選人）；ideal candidate（理想人選）；candidate for（……的候選人）", "candidate for + 職位；invite someone to + 活動。", "人事與招募"),
    ("employee", "員工", 1, "All employees must wear an identification badge.", "名詞（可數）", "full-time employee（全職員工）；employee benefits（員工福利）；new employee（新進員工）", "all + 複數名詞；employee 與 employer 不同。", "人事與招募"),
    ("interview", "面試；訪談", 1, "She has a job interview tomorrow morning.", "名詞／動詞", "job interview（工作面試）；conduct an interview（進行訪談）；interview for（面試……職位）", "have an interview for + 職位；interview + 人。", "人事與招募"),
    ("position", "職位；位置", 2, "The company is hiring for a sales position.", "名詞（可數）", "apply for a position（申請職位）；full-time position（全職職位）；vacant position（職缺）", "position in + 部門；position as + 職稱。", "人事與招募"),
    ("qualification", "資格；資歷", 2, "Experience is an important qualification for this position.", "名詞（可數）", "meet the qualifications（符合資格）；academic qualification（學歷）；qualification for（……的資格）", "qualification for + 職位；qualified to + 原形動詞。", "人事與招募"),
    ("account", "帳戶；帳目", 1, "The payment was transferred to our business account.", "名詞（可數）", "bank account（銀行帳戶）；open an account（開戶）；account balance（帳戶餘額）", "on account of 表示因為；account for 可表示占比或解釋。", "財務與預算"),
    ("budget", "預算", 1, "The project was completed within budget.", "名詞／動詞", "annual budget（年度預算）；within budget（預算內）；budget for（為……編列預算）", "within／over budget；budget for + 名詞。", "財務與預算"),
    ("expense", "費用；支出", 2, "Travel expenses will be reimbursed next month.", "名詞（可數／不可數）", "travel expenses（差旅費）；business expense（業務支出）；at the expense of（以犧牲……為代價）", "個別支出常用複數 expenses；at one's expense 表由某人付費。", "財務與預算"),
    ("invoice", "發票；請款單", 2, "The supplier sent an invoice for the equipment.", "名詞（可數）", "issue an invoice（開立發票）；invoice number（發票號碼）；invoice for（……的帳單）", "an invoice for + 商品／服務；invoice 可作動詞。", "財務與預算"),
    ("payment", "付款；款項", 1, "Payment is due within thirty days.", "名詞", "make a payment（付款）；payment method（付款方式）；payment due（應付款項）", "payment for + 商品；payment is due 表示款項到期。", "財務與預算"),
    ("revenue", "營收；收益", 3, "Online sales increased the company's annual revenue.", "名詞（不可數）", "annual revenue（年度營收）；generate revenue（創造營收）；revenue growth（營收成長）", "revenue 通常不可數；increase in revenue 表營收增加。", "財務與預算"),
    ("advertise", "廣告宣傳", 2, "The company will advertise the product online.", "動詞", "advertise a product（宣傳產品）；advertise online（線上刊登廣告）；advertise for staff（刊登徵人廣告）", "advertise + 商品；advertise for + 所需的人或物。", "行銷與採購"),
    ("customer", "顧客", 1, "Customer feedback helps us improve our service.", "名詞（可數）", "customer service（客戶服務）；potential customer（潛在客戶）；customer feedback（顧客回饋）", "customer 是購買者；client 常指接受專業服務的客戶。", "行銷與採購"),
    ("discount", "折扣；打折", 1, "Members receive a ten percent discount.", "名詞／動詞", "offer a discount（提供折扣）；at a discount（以折扣價）；discount rate（折扣率）", "a discount of + 比例；discount + 商品可作動詞。", "行銷與採購"),
    ("launch", "推出；上市", 2, "The company plans to launch a new service in June.", "動詞／名詞", "launch a product（推出產品）；official launch（正式上市）；product launch（產品發表）", "plan to launch + 受詞；launch 可作可數名詞。", "行銷與採購"),
    ("market", "市場；行銷", 2, "The firm plans to market the product overseas.", "名詞／動詞", "target market（目標市場）；market research（市場調查）；market a product（行銷產品）", "作動詞時直接接受詞；in the market for 表有意購買。", "行銷與採購"),
    ("purchase", "購買；採購", 1, "Customers can purchase tickets through the website.", "動詞／名詞", "make a purchase（購買）；purchase order（採購單）；purchase online（線上購買）", "purchase + 商品，語氣比 buy 正式；作名詞時可數。", "行銷與採購"),
    ("delivery", "運送；交付", 1, "Free delivery is available for large orders.", "名詞", "delivery date（交貨日期）；free delivery（免費配送）；take delivery of（收貨）", "delivery of + 商品；deliver something to + 地點／人。", "物流與庫存"),
    ("inventory", "庫存；盤點清單", 2, "The store checks its inventory every Friday.", "名詞", "inventory control（庫存管理）；in inventory（在庫）；take inventory（盤點）", "inventory 在美式英語常作集合名詞；an inventory of 表一份清單。", "物流與庫存"),
    ("order", "訂單；訂購", 1, "Your order will arrive within three business days.", "名詞／動詞", "place an order（下單）；order supplies（訂購用品）；in order（依序／妥當）", "order + 商品；place an order for + 商品。", "物流與庫存"),
    ("shipment", "貨物；出貨", 2, "The shipment was delayed by bad weather.", "名詞（可數）", "track a shipment（追蹤貨件）；shipment date（出貨日）；receive a shipment（收到貨件）", "shipment of + 商品；be delayed by + 原因。", "物流與庫存"),
    ("supplier", "供應商", 2, "We are looking for a reliable local supplier.", "名詞（可數）", "local supplier（當地供應商）；reliable supplier（可靠供應商）；supplier of（……的供應商）", "supplier of + 商品；supply something to someone。", "物流與庫存"),
    ("warehouse", "倉庫", 2, "The products are stored in a nearby warehouse.", "名詞（可數）", "distribution warehouse（配送倉庫）；warehouse staff（倉庫人員）；warehouse space（倉儲空間）", "in a warehouse；be stored in + 地點。", "物流與庫存"),
    ("accommodation", "住宿", 2, "The conference fee includes accommodation.", "名詞", "hotel accommodation（旅館住宿）；book accommodation（預訂住宿）；accommodation fee（住宿費）", "英式英語通常不可數；美式英語常用 accommodations。", "旅行與交通"),
    ("board", "登上；董事會", 1, "Passengers may now board the train.", "動詞／名詞", "board a plane（登機）；board of directors（董事會）；on board（在交通工具上）", "board + 交通工具，中間不加 on；on board 表已在上面。", "旅行與交通"),
    ("cancel", "取消", 1, "You may cancel the reservation without a fee.", "動詞", "cancel a reservation（取消預訂）；cancel a flight（取消航班）；cancel without charge（免費取消）", "cancel + 名詞；美式過去式 canceled，英式亦可寫 cancelled。", "旅行與交通"),
    ("delay", "延誤；使延遲", 1, "The flight was delayed for two hours.", "名詞／動詞", "flight delay（航班延誤）；delay a meeting（延後會議）；without delay（立即）", "be delayed by + 原因；be delayed for + 時間長度。", "旅行與交通"),
    ("destination", "目的地", 2, "The train will reach its final destination at noon.", "名詞（可數）", "final destination（最終目的地）；travel destination（旅遊目的地）；destination airport（目的地機場）", "destination for + 旅客／用途；arrive at a destination。", "旅行與交通"),
    ("reservation", "預訂；保留", 1, "I would like to make a hotel reservation.", "名詞（可數）", "make a reservation（預訂）；confirm a reservation（確認預訂）；reservation for two（兩人訂位）", "a reservation for + 人數／日期；under + 姓名表示以某名義。", "旅行與交通"),
    ("contract", "合約", 2, "Both companies signed a three-year contract.", "名詞／動詞", "sign a contract（簽約）；contract terms（合約條款）；under contract（受合約約束）", "a contract with + 對象；a contract for + 服務／工作。", "一般商務"),
    ("negotiate", "協商；談判", 3, "The two sides are negotiating a new contract.", "動詞", "negotiate a contract（協商合約）；negotiate with（與……談判）；negotiation process（談判過程）", "negotiate with + 人；negotiate over + 議題。", "一般商務"),
    ("proposal", "提案；建議案", 2, "The committee approved the project proposal.", "名詞（可數）", "submit a proposal（提交提案）；approve a proposal（核准提案）；proposal for（……的提案）", "a proposal to + 原形動詞；a proposal for + 名詞。", "一般商務"),
    ("conference", "會議；研討會", 1, "More than two hundred people attended the conference.", "名詞（可數）", "annual conference（年度會議）；conference room（會議室）；attend a conference（參加會議）", "attend + 活動，中間不加 to；at a conference。", "一般商務"),
    ("department", "部門；科系", 1, "Please contact the accounting department.", "名詞（可數）", "sales department（業務部）；department manager（部門經理）；department store（百貨公司）", "the + 部門名稱 + department；work in a department。", "一般商務"),
    ("policy", "政策；規定", 2, "Employees must follow the company's safety policy.", "名詞（可數）", "company policy（公司政策）；insurance policy（保單）；return policy（退貨政策）", "a policy on + 議題；policy 的複數是 policies。", "一般商務"),
    ("equipment", "設備", 1, "New office equipment will arrive tomorrow.", "名詞（不可數）", "office equipment（辦公設備）；safety equipment（安全設備）；piece of equipment（一件設備）", "equipment 不加 s；計數時用 a piece of equipment。", "設施與技術"),
    ("facility", "設施；場所", 2, "The company opened a new production facility.", "名詞（可數）", "production facility（生產設施）；medical facility（醫療設施）；facility manager（設施經理）", "facility 常指單一場所；facilities 可泛指配套設施。", "設施與技術"),
    ("inspect", "檢查；視察", 2, "A technician will inspect the machine this afternoon.", "動詞", "inspect equipment（檢查設備）；inspect a building（檢查建築）；safety inspection（安全檢查）", "inspect + 受詞；inspection of + 受檢項目。", "設施與技術"),
    ("repair", "修理；修繕", 1, "The maintenance team repaired the elevator.", "動詞／名詞", "repair equipment（修理設備）；under repair（維修中）；repair costs（修繕費）", "repair + 受詞；make repairs to + 設備。", "設施與技術"),
    ("operate", "操作；營運", 2, "Only trained staff may operate this machine.", "動詞", "operate a machine（操作機器）；operate a business（經營企業）；operate efficiently（有效率地運作）", "operate + 機器／企業；operate in + 地區／市場。", "設施與技術"),
    ("technician", "技術人員", 2, "The technician installed the new computer system.", "名詞（可數）", "service technician（維修技師）；laboratory technician（實驗室技術員）；qualified technician（合格技師）", "technician in + 領域；have something repaired by a technician。", "設施與技術"),
]

TOEIC_CATEGORIES: dict[str, str] = {}
WORD_TRACKS: dict[str, str] = {word.word: "toeic700" for word in WORDS}
toeic_words: list[Word] = []
for spelling, meaning, level, example, part, phrases, grammar, category in TOEIC_CORE_DATA:
    toeic_words.append(
        Word(
            spelling, meaning, level, example,
            f"TOEIC {category}核心詞；以搭配與例句整體記憶",
            f"先記最常見搭配：{phrases.split('；')[0]}。",
        )
    )
    WORD_USAGE[spelling] = (part, phrases, grammar)
    PHRASE_NOTES[spelling] = phrases
    TOEIC_CATEGORIES[spelling] = category
    WORD_TRACKS[spelling] = "toeic700"

# TOEIC 核心詞優先於原有生活基礎詞出現在相同難度的學習排序中。
WORDS[:0] = toeic_words

EXTENDED_VERB_FORMS: dict[str, tuple[str, str, str, str, str, bool]] = {}


def generated_usage(spelling: str, meaning: str, part: str) -> tuple[str, str]:
    """為大字庫提供保守、可泛用的搭配框架，避免捏造特定慣用語。"""
    core_meaning = meaning.split("；")[0]
    if "動詞" in part:
        return (
            f"to {spelling}（去／進行「{core_meaning}」）；can {spelling}（能夠「{core_meaning}」）",
            f"情境句型：主詞 + {spelling} + 受詞／補語；實際是否接受詞需依例句判斷。",
        )
    if "形容詞" in part:
        return (
            f"be {spelling}（處於「{core_meaning}」的狀態）；{spelling} + 名詞（「{core_meaning}」的……）",
            "形容詞常放在 be／連綴動詞後，或置於名詞前修飾；留意比較級與介系詞搭配。",
        )
    if "副詞" in part:
        return (
            f"{spelling} + 動詞（以「{core_meaning}」的方式做……）；動詞 + {spelling}（依語氣位置使用）",
            "副詞位置依修飾範圍而變；練習時觀察它在動詞前後或句首的位置。",
        )
    return (
        f"形容詞 + {spelling}（描述「{core_meaning}」）；{spelling} + 介系詞片語（補充情境）",
        "名詞可作主詞、受詞或補語；是否可數及固定介系詞需以實際文章語境確認。",
    )


def load_extended_vocabulary() -> list[Word]:
    """載入離線擴充字庫；資料檔缺失時仍可使用人工精編核心詞。"""
    path = Path(__file__).with_name("toeic_vocabulary.json")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        rows = payload["words"]
        if not isinstance(rows, list):
            return []
    except (OSError, KeyError, TypeError, json.JSONDecodeError):
        return []

    existing = {word.word for word in WORDS}
    result: list[Word] = []
    for item in rows:
        try:
            spelling = str(item["word"])
            meaning = str(item["meaning"])
            part = str(item["part"])
            level = int(item["level"])
        except (KeyError, TypeError, ValueError):
            continue
        if (
            not re.fullmatch(r"[a-z]+", spelling) or spelling in existing
            or not meaning or not part or level not in range(1, 7)
        ):
            continue
        track = str(item.get("track", "ceec_advanced"))
        track_label = "TOEIC 700+ 高頻核心" if track == "toeic700" else "CEEC 7000 進階閱讀"
        phrases, grammar = generated_usage(spelling, meaning, part)
        word = Word(
            spelling, meaning, level, "",
            f"{track_label}；以六級難度與情境位置記憶，不硬拆字根",
            f"先記核心詞義「{meaning.split('；')[0]}」，再套入上方搭配框架。",
        )
        result.append(word)
        existing.add(spelling)
        WORD_USAGE[spelling] = (
            part,
            phrases,
            grammar,
        )
        PHRASE_NOTES[spelling] = WORD_USAGE[spelling][1]
        TOEIC_CATEGORIES[spelling] = "700+ 高頻" if track == "toeic700" else "CEEC 進階"
        WORD_TRACKS[spelling] = track
        forms = item.get("forms")
        if isinstance(forms, dict):
            try:
                EXTENDED_VERB_FORMS[spelling] = (
                    spelling, str(forms["third"]), str(forms["past"]),
                    str(forms["participle"]), str(forms["present_participle"]),
                    bool(forms["irregular"]),
                )
            except KeyError:
                pass
    return result


# 插在 48 個人工精編 TOEIC 核心詞之後、原有生活基礎詞之前。
WORDS[len(toeic_words):len(toeic_words)] = load_extended_vocabulary()


def toeic_category_for(word: Word) -> str:
    return TOEIC_CATEGORIES.get(word.word, "")


def usage_for(word: Word) -> tuple[str, str, str]:
    """回傳學習卡用法；自訂單詞沒有教材時提供清楚的預設提示。"""
    part_of_speech, phrases, grammar = WORD_USAGE.get(
        word.word,
        ("自訂單詞", "尚未加入常用片語", "可從例句觀察單詞在句中的位置與搭配。"),
    )
    return part_of_speech, PHRASE_NOTES.get(word.word, phrases), grammar


def learning_example_for(word: Word) -> str:
    """每個詞都要有可輸入的學習句；未精編詞使用不會誤導語法的通用句。"""
    return word.example or f'I am learning how to use the word "{word.word}" in context.'


def grammar_cloze_for(word: Word) -> dict[str, str]:
    """把第一組實用搭配轉成關鍵位置填空，優先考固定介系詞。"""
    _part, phrases, grammar = usage_for(word)
    first_phrase = phrases.split("；", 1)[0].strip()
    note_match = re.search(r"（([^）]+)）", first_phrase)
    chinese_note = note_match.group(1) if note_match else word.meaning.split("；", 1)[0]
    english = re.sub(r"（[^）]*）", "", first_phrase).strip()
    matches = list(re.finditer(r"[A-Za-z]+(?:'[A-Za-z]+)?", english))
    word_index = next(
        (index for index, match in enumerate(matches) if match.group(0).lower() == word.word.lower()),
        None,
    )
    prepositions = {
        "about", "after", "against", "at", "by", "for", "from", "in", "into",
        "of", "on", "over", "through", "to", "under", "with", "without",
    }
    target_index: int | None = word_index
    if word_index is not None and word_index + 1 < len(matches):
        following = matches[word_index + 1].group(0).lower()
        if following in prepositions:
            target_index = word_index + 1
    if target_index is None and matches:
        target_index = 0
    if target_index is None:
        english = word.word
        matches = list(re.finditer(r"[A-Za-z]+", english))
        target_index = 0
    target = matches[target_index]
    answer = target.group(0)
    cloze = english[:target.start()] + "_____" + english[target.end():]
    return {
        "cloze": cloze,
        "answer": answer,
        "note": chinese_note,
        "grammar": grammar,
    }


def cloze_matches(answer: str, expected: str) -> bool:
    return normalize(answer) == normalize(expected)


def sentence_matches(answer: str, expected: str) -> bool:
    """完整例句比較忽略大小寫與句尾標點，但保留單詞及詞序要求。"""
    return re.findall(r"[a-z0-9]+", answer.lower()) == re.findall(r"[a-z0-9]+", expected.lower())


# 原形、第三人稱單數、過去式、過去分詞、現在分詞、是否為不規則變化。
VERB_FORMS: dict[str, tuple[str, str, str, str, str, bool]] = {
    "confirm": ("confirm", "confirms", "confirmed", "confirmed", "confirming", False),
    "document": ("document", "documents", "documented", "documented", "documenting", False),
    "schedule": ("schedule", "schedules", "scheduled", "scheduled", "scheduling", False),
    "interview": ("interview", "interviews", "interviewed", "interviewed", "interviewing", False),
    "budget": ("budget", "budgets", "budgeted", "budgeted", "budgeting", False),
    "advertise": ("advertise", "advertises", "advertised", "advertised", "advertising", False),
    "discount": ("discount", "discounts", "discounted", "discounted", "discounting", False),
    "launch": ("launch", "launches", "launched", "launched", "launching", False),
    "market": ("market", "markets", "marketed", "marketed", "marketing", False),
    "purchase": ("purchase", "purchases", "purchased", "purchased", "purchasing", False),
    "order": ("order", "orders", "ordered", "ordered", "ordering", False),
    "board": ("board", "boards", "boarded", "boarded", "boarding", False),
    "cancel": ("cancel", "cancels", "canceled", "canceled", "canceling", False),
    "delay": ("delay", "delays", "delayed", "delayed", "delaying", False),
    "contract": ("contract", "contracts", "contracted", "contracted", "contracting", False),
    "negotiate": ("negotiate", "negotiates", "negotiated", "negotiated", "negotiating", False),
    "inspect": ("inspect", "inspects", "inspected", "inspected", "inspecting", False),
    "repair": ("repair", "repairs", "repaired", "repaired", "repairing", False),
    "operate": ("operate", "operates", "operated", "operated", "operating", False),
    "water": ("water", "waters", "watered", "watered", "watering", False),
    "listen": ("listen", "listens", "listened", "listened", "listening", False),
    "answer": ("answer", "answers", "answered", "answered", "answering", False),
    "go": ("go", "goes", "went", "gone", "going", True),
    "eat": ("eat", "eats", "ate", "eaten", "eating", True),
    "see": ("see", "sees", "saw", "seen", "seeing", True),
    "remember": ("remember", "remembers", "remembered", "remembered", "remembering", False),
    "decide": ("decide", "decides", "decided", "decided", "deciding", False),
    "improve": ("improve", "improves", "improved", "improved", "improving", False),
    "prepare": ("prepare", "prepares", "prepared", "prepared", "preparing", False),
    "receive": ("receive", "receives", "received", "received", "receiving", False),
    "make": ("make", "makes", "made", "made", "making", True),
    "take": ("take", "takes", "took", "taken", "taking", True),
    "communicate": ("communicate", "communicates", "communicated", "communicated", "communicating", False),
    "experience": ("experience", "experiences", "experienced", "experienced", "experiencing", False),
    "recommend": ("recommend", "recommends", "recommended", "recommended", "recommending", False),
    "maintain": ("maintain", "maintains", "maintained", "maintained", "maintaining", False),
    "evaluate": ("evaluate", "evaluates", "evaluated", "evaluated", "evaluating", False),
    "acknowledge": ("acknowledge", "acknowledges", "acknowledged", "acknowledged", "acknowledging", False),
}
VERB_FORMS.update(EXTENDED_VERB_FORMS)

PRACTICE_MODE_LABELS = {
    "adaptive": "自動依難度",
    "spelling": "單詞拼寫",
    "verb_forms": "動詞變化",
    "sentence": "重點搭配／文法填空",
}

SKILL_LABELS = {
    "meaning": "詞義",
    "spelling": "拼字",
    "usage": "搭配",
    "forms": "變化",
}

RECALL_RATINGS = {
    "again": "忘記",
    "hard": "模糊",
    "good": "記得",
    "easy": "很熟",
}

# 常見考試混淆詞。只有實際答錯或標記困難的詞才會進入辨析練習。
CONFUSABLE_GROUPS = (
    ("accept", "except"),
    ("affect", "effect"),
    ("advice", "advise"),
    ("assure", "ensure", "insure"),
    ("complement", "compliment"),
    ("economic", "economical"),
    ("emigrate", "immigrate"),
    ("later", "latter"),
    ("personal", "personnel"),
    ("principal", "principle"),
    ("quiet", "quite"),
    ("rise", "raise"),
    ("stationary", "stationery"),
    ("than", "then"),
    ("weather", "whether"),
)


def confusable_for(spelling: str) -> list[str]:
    """回傳人工整理的常見混淆詞，不包含查詢詞本身。"""
    spelling = normalize(spelling)
    for group in CONFUSABLE_GROUPS:
        if spelling in group:
            return [item for item in group if item != spelling]
    return []


def skill_for_exercise(exercise: dict[str, str | bool]) -> str:
    """把題型映射到可獨立追蹤的記憶能力。"""
    return {
        "verb_forms": "forms",
        "sentence": "usage",
        "confusion": "meaning",
    }.get(str(exercise.get("mode", "spelling")), "spelling")

EXAM_TARGET_LABELS = {
    "integrated7000": "TOEIC＋CEEC 7000",
    "toeic700": "TOEIC 700+ 核心",
}


def practice_mode_for(word: Word, requested: str = "adaptive") -> str:
    """選擇實際題型；不規則動詞優先練特殊變化，高階詞練完整語境。"""
    if requested == "verb_forms":
        return "verb_forms" if word.word in VERB_FORMS else "spelling"
    if requested == "sentence":
        return "sentence"
    if requested == "confusion":
        return "confusion"
    if requested == "spelling":
        return requested
    forms = VERB_FORMS.get(word.word)
    if forms and forms[-1]:
        return "verb_forms"
    if forms and word.level >= 3:
        return "verb_forms"
    if word.level >= 3:
        return "sentence"
    return "spelling"


def exercise_for(word: Word, requested: str = "adaptive") -> dict[str, str | bool]:
    """建立 GUI 與測試可共用的練習題描述。"""
    mode = practice_mode_for(word, requested)
    if mode == "verb_forms":
        base, third, past, participle, present_participle, irregular = VERB_FORMS[word.word]
        variant = "特殊變化（不規則動詞）" if irregular else "規則變化"
        return {
            "mode": mode,
            "title": "動詞變化",
            "instruction": "依序輸入過去式與過去分詞（可用空格、逗號或 / 分隔）",
            "prompt": f"原形：{base}　第三人稱：{third}　現在分詞：{present_participle}\n{variant}",
            "answer": f"{past} / {participle}",
            "irregular": irregular,
        }
    if mode == "sentence":
        cloze = grammar_cloze_for(word)
        return {
            "mode": mode,
            "title": "重點搭配／文法填空",
            "instruction": "輸入空格中的核心單詞或固定介系詞",
            "prompt": f"搭配：{cloze['cloze']}（{cloze['note']}）\n文法提示：{cloze['grammar']}",
            "answer": cloze["answer"],
            "irregular": False,
        }
    blank = word.example.replace(word.word, "_____").replace(word.word.capitalize(), "_____")
    if mode == "confusion":
        alternatives = confusable_for(word.word)
        contrast = "、".join(alternatives) if alternatives else "其他相近詞"
        return {
            "mode": mode,
            "title": "易混淆詞辨析",
            "instruction": "依中文與句意輸入最適合的單詞",
            "prompt": f"中文：{word.meaning}\n{blank}\n辨析範圍：{word.word}、{contrast}",
            "answer": word.word,
            "irregular": False,
        }
    return {
        "mode": "spelling",
        "title": "單詞拼寫",
        "instruction": "依中文與例句輸入正確單詞",
        "prompt": f"中文：{word.meaning}\n{blank}",
        "answer": word.word,
        "irregular": False,
    }


def answer_matches(answer: str, exercise: dict[str, str | bool]) -> bool:
    """依題型比較答案，忽略不影響學習目標的大小寫與標點差異。"""
    expected = str(exercise["answer"])
    mode = exercise["mode"]
    if mode in {"spelling", "confusion"}:
        return normalize(answer) == normalize(expected)
    if mode == "sentence":
        return cloze_matches(answer, expected)
    typed_forms = re.findall(r"[a-z]+", answer.lower())
    expected_forms = re.findall(r"[a-z]+", expected.lower())
    if len(expected_forms) == 2 and expected_forms[0] == expected_forms[1]:
        return typed_forms in (expected_forms, expected_forms[:1])
    return typed_forms == expected_forms


def exercise_hint(word: Word, exercise: dict[str, str | bool], stage: int) -> str:
    mode = exercise["mode"]
    expected = str(exercise["answer"])
    if mode in {"spelling", "confusion"}:
        return reveal_hint(word, stage)
    if mode == "verb_forms":
        forms = re.findall(r"[a-z]+", expected.lower())
        if stage == 1:
            return "兩個答案的開頭：" + " / ".join(form[0].upper() for form in forms)
        if stage == 2:
            return "字母數：" + " / ".join(str(len(form)) for form in forms)
        return "特殊變化需整體記憶。" if exercise["irregular"] else "規則動詞通常以 -ed 形成過去式。"
    words = re.findall(r"[A-Za-z']+", expected)
    if stage == 1:
        return f"句子共 {len(words)} 個單詞，開頭是：{words[0] if words else ''}"
    if stage == 2:
        return "句型骨架：" + " ".join(w if i % 2 == 0 else "_____" for i, w in enumerate(words))
    return f"重點文法：{usage_for(word)[2]}"


# 教材採「常見規律＋例字」呈現；不是每個單詞都適合機械式拆解。
WORD_PARTS_GUIDE = [
    ("否定字首", "un-", "不、相反", "unhappy, unfair"),
    ("否定字首", "in-", "不、非", "independent, incorrect"),
    ("否定字首", "im-", "否定時是 in- 的變形；並非所有 im- 都是否定", "impossible；improve 是例外"),
    ("否定字首", "il- / ir-", "in- 在 l／r 前的變形", "illegal, irregular"),
    ("常用字首", "re-", "再次、向後", "rewrite, return"),
    ("常用字首", "pre-", "在前、預先", "prepare, preview"),
    ("常用字首", "dis-", "不、分離、相反", "disagree, disconnect"),
    ("常用字首", "mis-", "錯誤地", "misunderstand, misspell"),
    ("核心字根", "port", "帶、運送", "transport, portable"),
    ("核心字根", "spect", "看", "inspect, spectator"),
    ("核心字根", "dict", "說、宣告", "predict, dictionary"),
    ("核心字根", "vis / vid", "看", "visible, video"),
    ("核心字根", "tract", "拉、牽引", "attract, contract"),
    ("核心字根", "form", "形狀、形成", "inform, transform"),
    ("核心字根", "graph", "寫、記錄", "autograph, paragraph"),
    ("核心字根", "phon", "聲音", "telephone, microphone"),
    ("核心字根", "struct", "建造", "construct, structure"),
    ("名詞字尾", "-tion / -sion", "動作、狀態、結果", "action, decision"),
    ("名詞字尾", "-ment", "動作、狀態、結果", "environment, improvement"),
    ("名詞字尾", "-ness", "性質、狀態", "happiness, kindness"),
    ("名詞字尾", "-ity", "性質、狀態", "opportunity, ability"),
    ("形容詞字尾", "-ful", "充滿…的", "careful, successful"),
    ("形容詞字尾", "-less", "沒有…的", "careless, hopeless"),
    ("形容詞字尾", "-able / -ible", "可以…的", "available, possible"),
    ("形容詞字尾", "-ant / -ent", "具有某種性質", "important, different"),
    ("形容詞字尾", "-al / -ial", "與…相關的", "natural, essential"),
    ("形容詞字尾", "-ive", "具有…性質的", "active, effective"),
    ("副詞字尾", "-ly", "以某種方式", "carefully, clearly"),
    ("動詞字尾", "-ate", "使成為、進行", "communicate, evaluate"),
    ("動詞字尾", "-ize / -ify", "使成為", "organize, simplify"),
]


def default_progress() -> dict:
    return {
        "words": {}, "days": {}, "custom_words": [],
        "settings": {
            "new_words_per_day": 5, "review_words_per_day": 20,
            "practice_mode": "adaptive", "exam_target": "integrated7000",
            "reinforcement_repetitions": 5,
        },
        "sessions": 0, "last_session": None,
    }


def load_progress() -> dict:
    if not DATA_FILE.exists():
        return default_progress()
    try:
        data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        if not isinstance(data.get("words"), dict):
            raise ValueError
        data.setdefault("days", {})
        data.setdefault("custom_words", [])
        if not isinstance(data["custom_words"], list):
            data["custom_words"] = []
        settings = data.setdefault("settings", {})
        if not isinstance(settings, dict):
            settings = data["settings"] = {}
        settings.setdefault("new_words_per_day", 5)
        settings.setdefault("review_words_per_day", 20)
        settings.setdefault("practice_mode", "adaptive")
        settings.setdefault("exam_target", "integrated7000")
        settings.setdefault("reinforcement_repetitions", 5)
        return data
    except (OSError, json.JSONDecodeError, ValueError):
        print("提醒：進度檔無法讀取，本次將使用新進度（原檔不會刪除）。")
        return default_progress()


def save_progress(progress: dict) -> None:
    progress["last_session"] = datetime.now().isoformat(timespec="seconds")
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    temp = DATA_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(progress, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(DATA_FILE)


def stats_for(progress: dict, spelling: str) -> dict:
    stat = progress["words"].setdefault(
        spelling, {"correct": 0, "wrong": 0, "streak": 0, "mastery": 0}
    )
    for key in ("correct", "wrong", "streak", "mastery"):
        stat.setdefault(key, 0)
    stat.setdefault("known", False)
    stat.setdefault("difficult", False)
    stat.setdefault("reinforcement_sessions", 0)
    stat.setdefault(
        "stability",
        float((1, 1, 3, 7, 14, 30)[max(0, min(5, int(stat["mastery"])))])
    )
    stat.setdefault("last_interval", max(1, int(round(float(stat["stability"])))))
    stat.setdefault("reviews", int(stat.get("correct", 0)) + int(stat.get("wrong", 0)))
    stat.setdefault("lapses", int(stat.get("wrong", 0)))
    skill_mastery = stat.setdefault("skill_mastery", {})
    if not isinstance(skill_mastery, dict):
        skill_mastery = stat["skill_mastery"] = {}
    for skill in SKILL_LABELS:
        skill_mastery.setdefault(skill, int(stat["mastery"]))
    if not isinstance(stat.get("confusions"), dict):
        stat["confusions"] = {}
    if not isinstance(stat.get("rating_history"), list):
        stat["rating_history"] = []
    if not isinstance(stat.get("spelling_mistakes"), dict):
        stat["spelling_mistakes"] = {}
    return stat


def skill_summary(stat: dict) -> str:
    """以緊湊文字顯示各能力熟練度。"""
    skills = stat.get("skill_mastery", {})
    return "　".join(
        f"{label} {int(skills.get(key, 0))}/5" for key, label in SKILL_LABELS.items()
    )


def record_confusion(progress: dict, spelling: str, answer: str) -> str | None:
    """若答案是另一個已知單詞，記錄成個人的易混淆關係。"""
    typed = normalize(answer)
    expected = normalize(spelling)
    if not typed or typed == expected:
        return None
    known_words = {word.word for word in all_words(progress)}
    if typed not in known_words:
        return None
    stat = stats_for(progress, spelling)
    confusions = stat["confusions"]
    confusions[typed] = int(confusions.get(typed, 0)) + 1
    stat["difficult"] = True
    return typed


def confusion_words(progress: dict) -> list[Word]:
    """回傳適合進行易混淆辨析的個人錯題。"""
    result = []
    for word in all_words(progress):
        stat = progress.get("words", {}).get(word.word, {})
        confusions = stat.get("confusions", {})
        if not isinstance(confusions, dict):
            confusions = {}
        if confusions or ((stat.get("wrong") or stat.get("difficult")) and confusable_for(word.word)):
            result.append(word)
    return sorted(
        result,
        key=lambda word: (
            -sum(stats_for(progress, word.word)["confusions"].values()),
            -int(stats_for(progress, word.word)["wrong"]),
            word.word,
        ),
    )


def record_daily_word(progress: dict, spelling: str, activity: str = "學習") -> bool:
    """記錄某日實際接觸過的單詞；重複開啟同一詞不會重複列出。"""
    day = progress.setdefault("days", {}).setdefault(date.today().isoformat(), {})
    names = day.setdefault("word_names", [])
    if not isinstance(names, list):
        names = day["word_names"] = []
    changed = False
    if spelling not in names:
        names.append(spelling)
        changed = True
    activities = day.setdefault("word_activities", {})
    if not isinstance(activities, dict):
        activities = day["word_activities"] = {}
    labels = activities.setdefault(spelling, [])
    if not isinstance(labels, list):
        labels = activities[spelling] = []
    if activity not in labels:
        labels.append(activity)
        changed = True
    return changed


def words_on_date(progress: dict, on_date: date | None = None) -> list[tuple[Word, str]]:
    """回傳指定日期學過或作答過的單詞與活動，並相容尚無清單的舊進度。"""
    target = (on_date or date.today()).isoformat()
    day = progress.get("days", {}).get(target, {})
    names = day.get("word_names", []) if isinstance(day, dict) else []
    ordered = [str(name) for name in names] if isinstance(names, list) else []
    for word in all_words(progress):
        stat = progress.get("words", {}).get(word.word, {})
        if stat.get("last_review") == target and word.word not in ordered:
            ordered.append(word.word)
    activities = day.get("word_activities", {}) if isinstance(day, dict) else {}
    lookup = {word.word: word for word in all_words(progress)}
    result: list[tuple[Word, str]] = []
    for spelling in ordered:
        word = lookup.get(spelling)
        if word is None:
            continue
        labels = activities.get(spelling, []) if isinstance(activities, dict) else []
        if not isinstance(labels, list):
            labels = []
        activity = "、".join(str(label) for label in labels) or "練習"
        result.append((word, activity))
    return result


def record_reinforcement_mistake(progress: dict, spelling: str, answer: str) -> int:
    """記錄強化抄寫第一次不一致的位置，回傳一基準位置。"""
    expected = normalize(spelling)
    typed = normalize(answer)
    mismatch = next(
        (index for index, pair in enumerate(zip(typed, expected)) if pair[0] != pair[1]),
        min(len(typed), len(expected)),
    )
    position = mismatch + 1
    stat = stats_for(progress, spelling)
    mistakes = stat["spelling_mistakes"]
    key = str(position)
    mistakes[key] = int(mistakes.get(key, 0)) + 1
    stat["difficult"] = True
    return position


def all_words(progress: dict) -> list[Word]:
    """合併內建與使用者自訂單詞，忽略損壞的舊資料。"""
    result = list(WORDS)
    known = {word.word for word in result}
    for item in progress.get("custom_words", []):
        if not isinstance(item, dict):
            continue
        try:
            word = Word(
                word=str(item["word"]),
                meaning=str(item["meaning"]),
                level=int(item.get("level", 2)),
                example=str(item.get("example", "")),
                pattern=str(item.get("pattern", "自訂單詞；不必硬拆字根")),
                memory=str(item.get("memory", "配合自己的情境記憶。")),
            )
        except (KeyError, TypeError, ValueError):
            continue
        if re.fullmatch(r"[a-z]+", word.word) and word.word not in known:
            result.append(word)
            known.add(word.word)
    return result


def words_for_target(progress: dict, target: str = "integrated7000") -> list[Word]:
    """回傳指定備考目標的字庫；自訂詞永遠納入使用者自己的學習範圍。"""
    words = all_words(progress)
    if target != "toeic700":
        return words
    custom = {str(item.get("word", "")) for item in progress.get("custom_words", []) if isinstance(item, dict)}
    return [
        word for word in words
        if WORD_TRACKS.get(word.word) == "toeic700" or word.word in custom
    ]


def study_words(progress: dict, target: str = "integrated7000") -> list[Word]:
    return [
        word for word in words_for_target(progress, target)
        if not progress.get("words", {}).get(word.word, {}).get("known", False)
    ]


def review_summary(progress: dict, target: str = "integrated7000") -> dict[str, int | float]:
    words = words_for_target(progress, target)
    stats = [progress.get("words", {}).get(word.word, {}) for word in words]
    attempted = [stat for stat in stats if stat.get("correct", 0) + stat.get("wrong", 0)]
    correct = sum(int(stat.get("correct", 0)) for stat in attempted)
    wrong = sum(int(stat.get("wrong", 0)) for stat in attempted)
    return {
        "total": len(words),
        "started": len(attempted),
        "mastered": sum(bool(stat.get("known")) or int(stat.get("mastery", 0)) >= 5 for stat in stats),
        "difficult": sum(bool(stat.get("difficult")) for stat in stats),
        "accuracy": correct / (correct + wrong) if correct + wrong else 0.0,
    }


def level_progress(progress: dict, target: str = "integrated7000") -> list[dict[str, int]]:
    """提供六級字庫的接觸與掌握數，讓大型備考範圍仍可被追蹤。"""
    result: list[dict[str, int]] = []
    for level in range(1, 7):
        words = [word for word in words_for_target(progress, target) if word.level == level]
        stats = [progress.get("words", {}).get(word.word, {}) for word in words]
        result.append({
            "level": level,
            "total": len(words),
            "started": sum(bool(stat.get("correct", 0) + stat.get("wrong", 0)) for stat in stats),
            "mastered": sum(bool(stat.get("known")) or int(stat.get("mastery", 0)) >= 5 for stat in stats),
        })
    return result


def add_custom_word(
    progress: dict, spelling: str, meaning: str, example: str = "",
    pattern: str = "", memory: str = "",
) -> Word:
    spelling = spelling.strip().lower()
    meaning = meaning.strip()
    if not re.fullmatch(r"[a-z]+", spelling):
        raise ValueError("英文單詞只能包含英文字母。")
    if not meaning:
        raise ValueError("請輸入中文解釋。")
    if spelling in {word.word for word in all_words(progress)}:
        raise ValueError("這個單詞已經存在。")
    word = Word(
        spelling,
        meaning,
        2,
        example.strip() or f'I am learning the word "{spelling}".',
        pattern.strip() or "自訂單詞；不必硬拆字根",
        memory.strip() or "配合自己的情境記憶。",
    )
    progress.setdefault("custom_words", []).append(asdict(word))
    return word


def delete_custom_word(progress: dict, spelling: str) -> bool:
    custom = progress.setdefault("custom_words", [])
    remaining = [
        item for item in custom
        if not isinstance(item, dict) or item.get("word") != spelling
    ]
    if len(remaining) == len(custom):
        return False
    progress["custom_words"] = remaining
    progress.get("words", {}).pop(spelling, None)
    return True


def update_custom_word(
    progress: dict, original: str, spelling: str, meaning: str, example: str = "",
    pattern: str = "", memory: str = "",
) -> Word:
    spelling = spelling.strip().lower()
    meaning = meaning.strip()
    if not re.fullmatch(r"[a-z]+", spelling):
        raise ValueError("英文單詞只能包含英文字母。")
    if not meaning:
        raise ValueError("請輸入中文解釋。")
    existing = {word.word for word in all_words(progress) if word.word != original}
    if spelling in existing:
        raise ValueError("這個單詞已經存在。")
    custom = progress.setdefault("custom_words", [])
    index = next(
        (i for i, item in enumerate(custom)
         if isinstance(item, dict) and item.get("word") == original),
        None,
    )
    if index is None:
        raise ValueError("找不到要編輯的自訂單詞。")
    word = Word(
        spelling, meaning, int(custom[index].get("level", 2)),
        example.strip() or f'I am learning the word "{spelling}".',
        pattern.strip() or "自訂單詞；不必硬拆字根",
        memory.strip() or "配合自己的情境記憶。",
    )
    custom[index] = asdict(word)
    if spelling != original and original in progress.get("words", {}):
        progress["words"][spelling] = progress["words"].pop(original)
    return word


def search_words(progress: dict, query: str, custom_only: bool = False) -> list[Word]:
    query = query.strip().lower()
    words = all_words(progress)
    if custom_only:
        words = words[len(WORDS):]
    if not query:
        return words
    return [
        word for word in words
        if query in word.word.lower() or query in word.meaning.lower()
        or query in word.example.lower() or query in word.pattern.lower()
    ]


def set_word_flag(progress: dict, spelling: str, flag: str, value: bool) -> dict:
    if flag not in {"known", "difficult"}:
        raise ValueError("不支援的單詞狀態。")
    stat = stats_for(progress, spelling)
    stat[flag] = bool(value)
    if flag == "known" and value:
        stat["difficult"] = False
    return stat


def wrong_stage(stat: dict) -> str:
    if stat.get("wrong", 0) <= 0:
        return ""
    if stat.get("mastery", 0) >= 4 and stat.get("streak", 0) >= 3:
        return "已改善"
    if stat.get("wrong", 0) >= 5 and stat.get("mastery", 0) <= 2:
        return "頑固單詞"
    if stat.get("streak", 0) >= 1:
        return "改善中"
    return "待改善"


def record_result(
    progress: dict, spelling: str, correct: bool, mastery_gain: int = 1,
    skill: str = "spelling", rating: str | None = None,
) -> dict:
    """依回想感受、既有穩定度與分項能力安排下一次複習。"""
    stat = stats_for(progress, spelling)
    today = date.today()
    record_daily_word(progress, spelling, "作答")
    stat["last_review"] = today.isoformat()
    rating = rating if rating in RECALL_RATINGS else ("good" if correct else "again")
    if not correct:
        rating = "again"
    elif rating == "again":
        rating = "hard"
    skill = skill if skill in SKILL_LABELS else "spelling"
    skill_mastery = stat["skill_mastery"]
    stability = max(1.0, float(stat.get("stability", 1.0)))
    if correct:
        stat["correct"] += 1
        stat["streak"] += 1
        gain = mastery_gain + (1 if rating == "easy" else 0)
        skill_mastery[skill] = min(5, int(skill_mastery.get(skill, 0)) + gain)
        multiplier = {"hard": 1.25, "good": 1.9, "easy": 2.7}[rating]
        stability = min(365.0, max(1.0, stability * multiplier))
        interval = max(1, min(365, int(round(stability))))
        if stat["difficult"]:
            interval = max(1, int(round(interval * 0.7)))
        stat["last_result"] = "correct"
    else:
        stat["wrong"] += 1
        stat["streak"] = 0
        stat["lapses"] += 1
        skill_mastery[skill] = max(0, int(skill_mastery.get(skill, 0)) - 1)
        stability = max(1.0, stability * 0.45)
        interval = 1
        stat["last_result"] = "wrong"
        if stat["wrong"] >= 5:
            stat["difficult"] = True
    practiced = [int(value) for value in skill_mastery.values() if int(value) > 0]
    stat["mastery"] = round(sum(practiced) / len(practiced)) if practiced else 0
    stat["stability"] = round(stability, 2)
    stat["last_interval"] = interval
    stat["reviews"] += 1
    stat["last_rating"] = rating
    history = stat["rating_history"]
    history.append({"date": today.isoformat(), "rating": rating, "skill": skill})
    if len(history) > 60:
        del history[:-60]
    stat["next_review"] = (today + timedelta(days=interval)).isoformat()
    return stat


def due_words(progress: dict, on_date: date | None = None) -> list[Word]:
    target_date = on_date or date.today()
    target = target_date.isoformat()
    due = []
    for word in study_words(progress):
        stat = progress.get("words", {}).get(word.word, {})
        attempts = stat.get("correct", 0) + stat.get("wrong", 0)
        next_review = stat.get("next_review")
        if attempts and (not isinstance(next_review, str) or next_review <= target):
            due.append(word)
    def priority(word: Word) -> tuple:
        stat = stats_for(progress, word.word)
        try:
            due_date = date.fromisoformat(stat.get("next_review", target))
        except (TypeError, ValueError):
            due_date = target_date
        overdue = max(0, (target_date - due_date).days)
        confusion_count = sum(int(value) for value in stat.get("confusions", {}).values())
        return (-int(stat["difficult"]), -confusion_count, -overdue,
                stat["mastery"], -stat["wrong"], word.word)
    return sorted(due, key=priority)


def wrong_words(progress: dict, include_improved: bool = False) -> list[Word]:
    return sorted(
        [
            word for word in all_words(progress)
            if progress.get("words", {}).get(word.word, {}).get("wrong", 0)
            and (include_improved or wrong_stage(stats_for(progress, word.word)) != "已改善")
            and (include_improved or not stats_for(progress, word.word)["known"])
        ],
        key=lambda word: (
            {"頑固單詞": 0, "待改善": 1, "改善中": 2, "已改善": 3}.get(
                wrong_stage(stats_for(progress, word.word)), 4
            ),
            -stats_for(progress, word.word)["wrong"], word.word,
        ),
    )


def next_review_date(progress: dict, after: date | None = None) -> str | None:
    boundary = (after or date.today()).isoformat()
    dates = [
        progress.get("words", {}).get(word.word, {}).get("next_review")
        for word in study_words(progress)
    ]
    future = sorted(value for value in dates if isinstance(value, str) and value > boundary)
    return future[0] if future else None


def normalize(text: str) -> str:
    return re.sub(r"[^a-z]", "", text.lower())


def choose_word(pool: list[Word], progress: dict, recent: list[str]) -> Word:
    candidates = [word for word in pool if word.word not in recent[-2:]] or pool
    weights = []
    for word in candidates:
        stat = stats_for(progress, word.word)
        # 錯題及尚未熟練的字會更常出現；答對連續三次後降低頻率。
        weight = 2 + stat["wrong"] * 3 + max(0, 3 - stat["mastery"])
        weight += 5 if stat["wrong"] > 0 and stat["streak"] < 2 else 0
        weights.append(weight)
    return random.choices(candidates, weights=weights, k=1)[0]


def reveal_hint(word: Word, stage: int) -> str:
    if stage == 1:
        return f"首字母：{word.word[0].upper()}，共 {len(word.word)} 個字母"
    if stage == 2:
        shown = "".join(ch if i % 2 == 0 else "_" for i, ch in enumerate(word.word))
        return f"拼字骨架：{shown}"
    return f"字詞提示：{word.pattern}"


def explain_mistake(word: Word, answer: str) -> None:
    answer = normalize(answer)
    print(f"\n  正確答案：{word.word}  /  {word.meaning}")
    if answer:
        mismatch = next(
            (i for i, pair in enumerate(zip(answer, word.word)) if pair[0] != pair[1]),
            min(len(answer), len(word.word)),
        )
        print(f"  拼字觀察：前 {mismatch} 個字母正確；請留意後面的「{word.word[mismatch:]}」。")
    print(f"  字詞觀察：{word.pattern}")
    print(f"  記憶法：{word.memory}")
    print(f"  例句：{word.example}")
    print("  這個字已加入錯題回流，稍後會再次出現。")


def ask_word(word: Word, progress: dict, number: int, total: int) -> bool | None:
    stat = stats_for(progress, word.word)
    print(f"\n[{number}/{total}] Level {word.level}｜熟練度 {stat['mastery']}/5")
    print(f"中文：{word.meaning}")
    print(f"例句：{word.example.replace(word.word, '_____').replace(word.word.capitalize(), '_____')}")
    hints = 0
    while True:
        raw = input("請輸入英文（? 提示／s 跳過／q 結束）：").strip()
        command = raw.lower()
        if command == "q":
            return None
        if command == "?":
            hints = min(hints + 1, 3)
            print("  " + reveal_hint(word, hints))
            continue
        if command == "s":
            explain_mistake(word, "")
            record_result(progress, word.word, False)
            return False
        if normalize(raw) == word.word:
            gain = 1 if hints < 2 else 0
            record_result(progress, word.word, True, gain)
            print(f"  ✓ 正確！{word.pattern}")
            print(f"  {word.memory}")
            return True
        record_result(progress, word.word, False)
        explain_mistake(word, raw)
        return False


def select_number(prompt: str, minimum: int, maximum: int, default: int) -> int:
    while True:
        raw = input(prompt).strip()
        if not raw:
            return default
        if raw.isdigit() and minimum <= int(raw) <= maximum:
            return int(raw)
        print(f"請輸入 {minimum}～{maximum} 的數字。")


def show_report(progress: dict) -> None:
    attempted = [(w, progress["words"].get(w.word, {})) for w in all_words(progress)]
    attempted = [(w, s) for w, s in attempted if s.get("correct", 0) + s.get("wrong", 0)]
    if not attempted:
        print("\n還沒有練習紀錄。")
        return
    correct = sum(s["correct"] for _, s in attempted)
    wrong = sum(s["wrong"] for _, s in attempted)
    print(f"\n累積作答：{correct + wrong} 題｜正確率：{correct / (correct + wrong):.0%}")
    weak = sorted(attempted, key=lambda item: (item[1]["mastery"], -item[1]["wrong"]))[:8]
    print("待加強：")
    for word, stat in weak:
        print(f"  {word.word:<15} {word.meaning:<14} 熟練度 {stat['mastery']}/5")


def practice(progress: dict) -> None:
    level = select_number("選擇最高難度 1～4（預設 1）：", 1, 4, 1)
    count = select_number("本輪題數 5～30（預設 10）：", 5, 30, 10)
    pool = [word for word in all_words(progress) if word.level <= level]
    recent: list[str] = []
    session_correct = 0
    answered = 0
    print("\n開始練習。大小寫不影響答案；輸入 ? 可逐步取得提示。")
    for number in range(1, count + 1):
        word = choose_word(pool, progress, recent)
        recent.append(word.word)
        result = ask_word(word, progress, number, count)
        if result is None:
            break
        answered += 1
        session_correct += int(result)
        save_progress(progress)
    progress["sessions"] = progress.get("sessions", 0) + 1
    save_progress(progress)
    if answered:
        print(f"\n本輪完成：{answered} 題，答對 {session_correct} 題（{session_correct / answered:.0%}）。")


def main() -> None:
    progress = load_progress()
    print("=" * 46)
    print("  Everyday English｜英文單詞練習器")
    print("  看中文、讀情境、親手拼出英文")
    print("=" * 46)
    while True:
        print("\n1. 開始練習   2. 查看學習報告   3. 離開")
        choice = input("請選擇：").strip()
        if choice == "1":
            practice(progress)
        elif choice == "2":
            show_report(progress)
        elif choice in {"3", "q", "Q"}:
            save_progress(progress)
            print("進度已保存。每天練一點，會比一次背很多更牢固！")
            break
        else:
            print("請輸入 1、2 或 3。")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\n練習已結束。")
