import unittest
from datetime import date, timedelta

import vocabulary_trainer as core


class AdaptiveReviewTests(unittest.TestCase):
    def test_old_progress_migrates_without_losing_mastery(self) -> None:
        progress = {
            "words": {"apple": {"correct": 3, "wrong": 1, "streak": 1, "mastery": 3}},
            "days": {}, "custom_words": [], "settings": {},
        }
        stat = core.stats_for(progress, "apple")
        self.assertEqual(set(stat["skill_mastery"]), set(core.SKILL_LABELS))
        self.assertTrue(all(value == 3 for value in stat["skill_mastery"].values()))

    def test_rating_changes_interval_and_target_skill(self) -> None:
        progress = core.default_progress()
        stat = core.record_result(
            progress, "apple", True, skill="spelling", rating="easy",
        )
        self.assertEqual(stat["skill_mastery"]["spelling"], 2)
        self.assertGreater(stat["next_review"], date.today().isoformat())
        failed = core.record_result(
            progress, "apple", False, skill="meaning", rating="again",
        )
        self.assertEqual(
            failed["next_review"], (date.today() + timedelta(days=1)).isoformat(),
        )

    def test_actual_known_word_error_becomes_confusion_drill(self) -> None:
        progress = core.default_progress()
        self.assertEqual(core.record_confusion(progress, "accept", "except"), "except")
        self.assertEqual(core.stats_for(progress, "accept")["confusions"]["except"], 1)
        self.assertIn("accept", [word.word for word in core.confusion_words(progress)])
        word = next(word for word in core.all_words(progress) if word.word == "accept")
        exercise = core.exercise_for(word, "confusion")
        self.assertEqual(exercise["mode"], "confusion")
        self.assertTrue(core.answer_matches("accept", exercise))

    def test_listing_confusions_does_not_create_thousands_of_stats(self) -> None:
        progress = core.default_progress()
        self.assertEqual(core.confusion_words(progress), [])
        self.assertEqual(progress["words"], {})


if __name__ == "__main__":
    unittest.main()
